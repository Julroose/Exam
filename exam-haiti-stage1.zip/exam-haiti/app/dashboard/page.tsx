import Header from "@/components/Header";

const progressBySubject = [
  { subject: "Mathématiques", percentage: 75 },
  { subject: "Français", percentage: 82 },
  { subject: "Sciences expérimentales", percentage: 68 }
];

export default function DashboardPage() {
  return (
    <>
      <Header title="Mon profil" />
      <main className="px-4 pb-8">
        <div className="pt-6">
          <h1 className="text-xl font-extrabold text-brand-900">
            Bonjour, Étudiant 👋
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Voici un résumé de ta progression.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-5">
          <div className="card text-center py-4">
            <p className="text-2xl font-extrabold text-brand-700">4</p>
            <p className="text-xs text-gray-500 mt-1">Quiz réalisés</p>
          </div>
          <div className="card text-center py-4">
            <p className="text-2xl font-extrabold text-brand-700">76%</p>
            <p className="text-xs text-gray-500 mt-1">Score moyen</p>
          </div>
          <div className="card text-center py-4">
            <p className="text-2xl font-extrabold text-brand-700">0</p>
            <p className="text-xs text-gray-500 mt-1">Examens blancs</p>
          </div>
          <div className="card text-center py-4">
            <p className="text-2xl font-extrabold text-accent-500">Gratuit</p>
            <p className="text-xs text-gray-500 mt-1">Statut du compte</p>
          </div>
        </div>

        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-wide mt-6 mb-3">
          Progression par matière
        </h2>
        <div className="flex flex-col gap-3">
          {progressBySubject.map((p) => (
            <div key={p.subject} className="card">
              <div className="flex justify-between text-sm font-medium mb-2">
                <span>{p.subject}</span>
                <span className="text-brand-700 font-semibold">
                  {p.percentage}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-brand-600 h-2 rounded-full"
                  style={{ width: `${p.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="card mt-6 text-center py-5">
          <p className="text-sm font-semibold text-gray-700">
            Passe au Premium pour débloquer tout le contenu
          </p>
          <button className="btn-primary mt-3">Voir les abonnements</button>
        </div>
      </main>
    </>
  );
}
